%====================================================================================
% Context ctxAndroidSensors standalone= SYSTEM-configuration: file it.unibo.ctxAndroidSensors.avatar.pl 
%====================================================================================
context(ctxandroidsensors, "localhost",  "TCP", "8013" ).  		 
%%% -------------------------------------------
